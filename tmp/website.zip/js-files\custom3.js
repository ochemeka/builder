// jQuery Initialization
jQuery(document).ready(function($){
"use strict"; 

      /* Testimonials ticker function call */ 
         $('.ticker_fade').list_ticker({
          speed:4000,
          effect:'fade'
        });

});